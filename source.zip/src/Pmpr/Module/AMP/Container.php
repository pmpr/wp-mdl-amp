<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668707eeadafa             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\56\x31"; const wcwemgogyesywcww = "\x68\x74\x74\x70\163\x3a\x2f\x2f\143\x64\156\x2e\x61\155\160\x70\x72\x6f\152\145\x63\x74\56\157\x72\147\57\x76\60"; use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }

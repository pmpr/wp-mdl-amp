<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6757f0d6ac6a0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\x2e\x31"; const wcwemgogyesywcww = "\150\x74\164\x70\163\x3a\57\57\143\144\156\x2e\x61\155\160\160\162\x6f\x6a\145\143\164\x2e\157\x72\x67\57\x76\60"; use CommonTrait; }

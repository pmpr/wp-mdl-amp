<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             675fab92bf512             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\x2e\61"; const wcwemgogyesywcww = "\x68\x74\x74\160\163\x3a\x2f\x2f\x63\144\156\x2e\x61\x6d\x70\x70\x72\x6f\152\x65\143\x74\x2e\x6f\162\x67\x2f\x76\60"; use CommonTrait; }

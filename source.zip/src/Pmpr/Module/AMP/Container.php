<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66ce116edcee0             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\x2e\61"; const wcwemgogyesywcww = "\150\x74\164\x70\163\72\57\57\143\144\156\x2e\x61\x6d\x70\160\x72\157\152\145\143\x74\x2e\x6f\x72\x67\x2f\166\x30"; use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }

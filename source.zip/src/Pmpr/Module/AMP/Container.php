<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523888894             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\56\61"; const wcwemgogyesywcww = "\x68\164\x74\160\x73\72\x2f\x2f\143\x64\x6e\56\141\155\x70\160\x72\157\152\x65\x63\x74\56\157\x72\147\57\166\x30"; use CommonTrait; }

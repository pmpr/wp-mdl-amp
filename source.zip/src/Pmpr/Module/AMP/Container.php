<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66e5ec4234afd             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\56\x31"; const wcwemgogyesywcww = "\150\164\164\160\x73\x3a\57\57\143\144\156\x2e\x61\x6d\160\x70\162\x6f\152\145\143\164\x2e\x6f\162\147\x2f\x76\60"; use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6d517ec1             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\56\x31"; const wcwemgogyesywcww = "\x68\164\x74\160\x73\x3a\x2f\57\x63\144\x6e\56\x61\x6d\x70\160\162\x6f\152\145\143\164\56\157\x72\147\x2f\166\x30"; use CommonTrait; }

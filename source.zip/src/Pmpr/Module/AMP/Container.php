<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4abfeba8b             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\x2e\x31"; const wcwemgogyesywcww = "\x68\164\x74\160\x73\72\x2f\57\x63\x64\x6e\x2e\141\155\160\160\162\x6f\x6a\145\x63\x74\56\x6f\x72\147\x2f\166\x30"; use CommonTrait; }

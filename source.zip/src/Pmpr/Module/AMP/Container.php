<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a6918a19a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\56\x31"; const wcwemgogyesywcww = "\x68\164\x74\x70\x73\x3a\x2f\57\143\x64\156\56\x61\x6d\160\160\x72\157\x6a\x65\143\164\56\157\x72\x67\x2f\x76\x30"; use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }

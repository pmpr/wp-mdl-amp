<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc510a5f8f             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\56\x31"; const wcwemgogyesywcww = "\150\164\164\x70\163\72\x2f\x2f\x63\144\x6e\56\141\x6d\160\x70\x72\x6f\x6a\x65\143\164\56\x6f\x72\x67\x2f\166\60"; use CommonTrait; }

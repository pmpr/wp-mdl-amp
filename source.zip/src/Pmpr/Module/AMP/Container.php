<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660691ee9d24a             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\x30\56\61"; const wcwemgogyesywcww = "\x68\x74\x74\x70\163\x3a\x2f\57\143\144\x6e\56\x61\x6d\x70\160\x72\157\x6a\x65\143\x74\56\157\162\147\57\x76\60"; use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }

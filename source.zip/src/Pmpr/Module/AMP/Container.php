<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e4951ee             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\x2e\61"; const wcwemgogyesywcww = "\x68\x74\164\x70\163\x3a\57\57\x63\144\156\x2e\x61\155\x70\x70\x72\x6f\152\145\x63\x74\x2e\x6f\162\147\x2f\x76\x30"; use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }

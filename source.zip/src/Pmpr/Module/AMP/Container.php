<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             668400ba08a49             |
    |_______________________________________|
*/
 namespace Pmpr\Module\AMP; use Pmpr\Common\Foundation\Container\Container as BaseClass; use Pmpr\Module\AMP\Traits\CommonTrait; abstract class Container extends BaseClass { const qgwkyemuiussyyoy = "\60\x2e\x31"; const wcwemgogyesywcww = "\150\x74\164\x70\x73\x3a\57\x2f\x63\x64\x6e\x2e\141\x6d\160\160\x72\157\x6a\x65\x63\164\x2e\157\x72\147\x2f\166\x30"; use CommonTrait; public function __construct() { $this->settingObj = Setting::symcgieuakksimmu(); parent::__construct(); } }

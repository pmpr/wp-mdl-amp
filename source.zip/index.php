<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a6918a19a             |
    |_______________________________________|
*/
 use Pmpr\Module\AMP\AMP; AMP::symcgieuakksimmu(); if (!function_exists("\151\163\137\141\x6d\x70")) { function is_amp() { return AMP::symcgieuakksimmu()->oywyqcgumoecwoga(); } } if (!function_exists("\151\163\137\x61\155\x70\137\x65\x6e\x64\160\157\151\156\164")) { function is_amp_endpoint() { return AMP::symcgieuakksimmu()->smowememmgeukwki(); } }

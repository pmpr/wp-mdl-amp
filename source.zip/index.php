<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4abfeba8b             |
    |_______________________________________|
*/
 use Pmpr\Module\AMP\AMP; AMP::symcgieuakksimmu(); if (!function_exists("\x69\163\137\x61\x6d\x70")) { function is_amp() { return AMP::symcgieuakksimmu()->oywyqcgumoecwoga(); } } if (!function_exists("\x69\163\x5f\x61\x6d\160\x5f\145\156\x64\x70\157\151\156\164")) { function is_amp_endpoint() { return AMP::symcgieuakksimmu()->smowememmgeukwki(); } }

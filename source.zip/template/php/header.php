<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             677fc510a5f8f             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\x63\150\x61\162\163\145\164"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\141\155\160\x5f\x77\x70\137\x68\x65\141\144"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\141\155\160\x5f\x62\x6f\144\x79\x5f\x6f\160\x65\156");

<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6646a6918a19a             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\143\150\x61\162\163\145\x74"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\x61\x6d\160\x5f\x77\160\x5f\150\x65\141\x64"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\x61\x6d\160\137\142\157\x64\x79\137\157\160\145\x6e");

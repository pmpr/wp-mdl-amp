<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6720b6d517ec1             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\143\x68\x61\162\x73\145\x74"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\x61\155\x70\137\167\x70\x5f\150\x65\141\x64"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\x61\155\160\x5f\x62\157\144\171\137\x6f\x70\145\x6e");

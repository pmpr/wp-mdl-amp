<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             660691ee9d24a             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\x63\x68\141\x72\163\x65\164"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\141\x6d\x70\137\x77\160\x5f\150\x65\141\x64"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\141\x6d\x70\137\x62\157\144\171\137\157\160\145\156");

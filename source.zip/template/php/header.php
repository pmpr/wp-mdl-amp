<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             6791523888894             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\143\150\141\x72\163\x65\x74"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\x61\x6d\x70\137\x77\160\x5f\x68\x65\x61\144"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\x61\155\160\x5f\x62\x6f\x64\171\x5f\157\x70\x65\156");

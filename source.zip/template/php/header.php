<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             66eae8e4951ee             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\x63\x68\x61\162\163\145\x74"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\141\155\x70\137\167\160\137\x68\x65\x61\x64"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\x61\x6d\160\137\x62\157\x64\171\137\x6f\x70\145\x6e");

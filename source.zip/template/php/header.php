<?php
/*   _______________________________________
    |  Obfuscated by PMPR - Php Obfuscator  |
    |             670d4abfeba8b             |
    |_______________________________________|
*/
ype html>
<html amp ⚡ <?php  language_attributes(); ?>>
<head>
	<meta charset="<?php  bloginfo("\x63\150\x61\x72\x73\x65\164"); ?>" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<?php  do_action("\141\x6d\160\137\x77\160\137\150\145\x61\144"); ?>
</head>
<body <?php  body_class(); ?>>
<?php  pmpr_do_action("\x61\x6d\x70\x5f\x62\x6f\144\x79\137\x6f\160\x65\156");
